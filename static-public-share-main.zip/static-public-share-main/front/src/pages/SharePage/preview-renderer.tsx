import React, { useEffect, useState } from "react";

type PreviewRendererProps = {
  url: string,
  render?: (text: string) => JSX.Element | JSX.Element[]
};

const PreviewRenderer = ({
  url,
  render = text => (
    <div
      onClick={e => {
        const selection = getSelection();

        if (selection && selection.isCollapsed) {
          const range = document.createRange();
          range.selectNode(e.currentTarget);

          selection.removeAllRanges();
          selection.addRange(range);
        }
      }}
      style={{
        textAlign: 'left',
      }}
    >
      {text.split(/\n+/).map((paragraph, i) => <p key={i}>{paragraph}</p>)}
    </div>
  )
}: PreviewRendererProps) => {
  const [text, setText] = useState<string>();

  useEffect(() => {
    fetch(url)
      .then(res => res.text())
      .then(text => setText(text))
      .catch(err => console.warn(err));
  }, [url]);

  return (
    <>
      {text && render(text)}
    </>
  );
};

export { PreviewRenderer, PreviewRendererProps };
