#!/bin/bash
service static-public-share start
