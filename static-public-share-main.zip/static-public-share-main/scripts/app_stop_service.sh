#!/bin/bash
service static-public-share stop
